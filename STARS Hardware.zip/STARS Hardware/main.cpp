
#include "mbed.h"
#include "SDFileSystem.h"
#include "cr_gps.h"
#include "BNO055.h"
#include "MPL3115A2.h"
#include <math.h>

#define pi 3.14159265358979323846 
#define GPS_BAUDRATE 9600
#define MPL3115A2_I2C_ADDRESS (0x60<<1)
#define DEBUG

//Sets the pins for the sensors
SDFileSystem sd(PB_15, PB_14, PB_13, PB_12, "sd"); // mosi, miso, sclk, cs
BNO055 imu(PB_11,PB_10);
MPL3115A2 altSensor(PB_9,PB_8, MPL3115A2_I2C_ADDRESS);
CelestialReachGPS gps(PA_9, PA_10, 9600);       // tx, rx


Serial pc(USBTX, USBRX);    // tx, rx
DigitalIn button(USER_BUTTON);      // button connects pin to GND
DigitalOut led_log(LED1);   // logging active


/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This Function will  create  a unique filename in a unique folder     :*/
/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
int get_filename(char *fn)
{
    //File Creation
    FILE *fp;
    
    DIR *d;
    char dirName[15];
    
    sprintf(dirName,"/sd/20%02d-%02d-%02d", gps.currentTime.year, gps.currentTime.month, gps.currentTime.day);
    
    d = opendir(dirName);
    if ( d == NULL ) {
        mkdir(dirName, 0777);
    }else{
        closedir(d);
    }

    sprintf(fn, "/sd/20%02d-%02d-%02d/%02d-%02d-%02d.csv", gps.currentTime.year, gps.currentTime.month, gps.currentTime.day, gps.currentTime.hour, gps.currentTime.minute, gps.currentTime.second);
    if ((fp = fopen(fn, "r")) == NULL) {
        // file does not exist yet
        return 0;
    } else {
        fclose(fp);
    }
    
    // filename pattern exhausted
    return -1;
}



/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This Function will  calculate distance using lat and long     :*/
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
double deg2rad(double);
double rad2deg(double);

double distance(double lat1, double lon1, double lat2, double lon2, char unit) {
  double theta, dist;
  theta = lon1 - lon2;
  dist = sin(deg2rad(lat1)) * sin(deg2rad(lat2)) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * cos(deg2rad(theta));
  dist = acos(dist);
  dist = rad2deg(dist);
  dist = dist * 60 * 1.1515;
  switch(unit) {
    case 'M':
      break;
    case 'K':
      dist = dist * 1.609344;
      break;
    case 'N':
      dist = dist * 0.8684;
      break;
  }
  return (dist);
}

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This function converts decimal degrees to radians             :*/
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
double deg2rad(double deg) {
  return (deg * pi / 180);
}

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This function converts radians to decimal degrees             :*/
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
double rad2deg(double rad) {
  return (rad * 180 / pi);
}

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This Function will set the time on the nucleo board to be the :*/
/*::  same as the time and date on the GPS.                         :*/
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
void setTime(){
    
    struct tm t;
    time_t t_of_day;
    t.tm_year = (2000 + gps.currentTime.year )-1900;
    t.tm_mon = gps.currentTime.month - 1;           // Month, 0 - jan
    t.tm_mday = gps.currentTime.day;          // Day of the month
    t.tm_hour = gps.currentTime.hour + (-6); // -6 converts UST to MST
    t.tm_min = gps.currentTime.minute;
    t.tm_sec = gps.currentTime.second;
    t.tm_isdst = -1;        // Is DST on? 1 = yes, 0 = no, -1 = unknown
    t_of_day = mktime(&t);
    set_time(t_of_day);
}


/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::  This is the main function of the program that runs everything.:*/
/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
int main() {
    char filename[30];
    double lat1 = 0; 
    double lon1 = 0; 
    double lat2 = 0; 
    double lon2 = 0;
    
    double gvel1 = 0;
    double vvel1 = 0;
    double fvel1 = 0;
    
    double vdist = 0;
    double gdist = 0;
    double gratio = 0;
    
    float sensor_data[2];

    double gvel2 = 0;
    double vvel2 = 0;
    double fvel2 = 0;
    
    double alt1 = 0;
    double alt2 = 0;
    
    button.mode(PullUp);
    
    while (1) {
        led_log = 0;
        
        #if defined(DEBUG)
        pc.printf("\n--------------------------------------------\n\r");
        pc.printf("GPS logging stopped, press button to start.\n\r");
        pc.printf("--------------------------------------------\n\r");
        #endif
        
        //Wait until button is pressed
        
        while (button);     // wait until button pressed
        wait_ms(50);        // button debounce
        while (!button);    // wait until button released
        setTime();
        if (get_filename(filename) != 0) {
            error("Could not create file with unique name\n");
        }

        
        #if defined(DEBUG)
        pc.printf("\n--------------------------------------------\n");
        pc.printf("GPS logging started, press button to stop.\n");
        pc.printf("Current logfile: %s\n", filename);
        pc.printf("--------------------------------------------\n");
        #endif
        
        imu.reset();
        led_log = 1;
        
        /*
         * BN005 Code
         */
        if (!imu.check())
            while (true){
           led_log = !led_log;
           wait(0.1);
           }
           
            imu.setmode(OPERATION_MODE_NDOF);
            imu.set_temp_units(CENTIGRADE);
            imu.set_accel_units(MPERSPERS);
            imu.set_angle_units(DEGREES);

            imu.write_calibration_data();
            imu.get_calib();
            while (imu.calib == 0) {
                imu.get_calib();
            }
        
        // open file for writing
        FILE *fp = fopen(filename, "w");
        if(fp == NULL) {
            error("Could not open file for write\n");
            while(1){
            led_log = !led_log;
            wait(0.5);    
            }
        }
         
               
        /*
         * MPL3115 Code
         */

        // Set over sampling value (see MPL3115A2.h for details)
        altSensor.Oversample_Ratio( OVERSAMPLE_RATIO_64);
        // Configure the sensor as Barometer.
        altSensor.Altimeter_Mode();
        
        
        /*
         * Write GPS data to file until button is pressed or
         * a write error occurs.
         */
         lat1 = gps.currentPosition.latitude;;
         lon1 = gps.currentPosition.longitude;
         
         //This flushes the altitude sensor
         altSensor.getAllData(&sensor_data[0]);
         wait(1);
         altSensor.getAllData(&sensor_data[0]);
         alt1 = sensor_data[0];
         alt2 = sensor_data[0];
         
        //Sets the top of the CSV so the parser and user know what each column is
        fprintf(fp, "time,latitude,longitude,pitch,yaw,roll,altitude,heading,gvelocity,vvelocity,fvelocity,xaccel,yaccel,zaccel,aoa,gratio,temperature,distance\n");
        fprintf(fp, "(yyyy-MM-ddTHH:mm:ssZ),(deg),(deg),(deg),(deg),(deg),(m),(deg),(km/hr),(km/hr),(km/hr),(m/s2),(m/s2),(m/s2),(deg),(ratio),(celsius),(km)\n");
        
        int rv = 0;
        //While loop that will print the data to the SD card
        do {    
            if(gps.hasReceivedData) {           
                //Print Time
                fprintf(fp, "20%02d-%02d-%02dT%02d:%02d:%02dZ,", gps.currentTime.year, gps.currentTime.month, gps.currentTime.day, 
                        gps.currentTime.hour, gps.currentTime.minute, gps.currentTime.second);
                
                //Print GPS
                lat2 = gps.currentPosition.latitude;
                lon2 = gps.currentPosition.longitude;
                fprintf(fp, "%f,%f,", lat2, lon2);
                
                //Print Angles
                imu.get_angles(); //query the i2c device
                fprintf(fp, "%6.2f,%6.2f,%6.2f,",imu.euler.pitch, imu.euler.yaw, imu.euler.roll);
                
                //Print Altitude and heading
                altSensor.getAllData( &sensor_data[0]);
                imu.get_mag();
                alt2= sensor_data[0];
                fprintf(fp, "%0.2f,%3.2f,", alt2, (atan2(imu.mag.y,imu.mag.x) * 180) / pi);
                
                 #if defined(DEBUG)
                pc.printf("\n--------------------------------------------\n");
                pc.printf("Altitude: %f\n", alt2);
                pc.printf("--------------------------------------------\n");
                #endif
                
                
                //Calculate ground velocity, vertical velocity and get the slope of the 2 called flightvelocity
                gdist = distance(lat1, lon1, lat2, lon2, 'K');
                vdist = alt1- alt2;
                
                
                gvel1 = gdist * 3600;
                
                vvel1 = vdist * 3600;
                fvel1 = sqrt(((pow(vvel1, 2)+pow(gvel1, 2))));
                
                //Print velocity calculations
                fprintf(fp, "%3.2f,%3.2f,%3.2f,", gvel1,vvel1,fvel1);
                  
                //Set these recorded points to be used for next round of iteration
                lat1 = lat2;
                lon1 = lon2;
                alt1 = alt2;
                 
                
                //Print acceleration calculations
                fprintf(fp, "%2.2f,%2.2f,%2.2f,", (gvel1 - gvel2) * 3.6, (vvel1 - vvel2) * 3.6, (fvel1 - fvel2) * 3.6); 
                
                //Set these recorded points to be used for next round of iteration
                gvel2 = gvel1;
                vvel2 = vvel1;
                fvel2 = fvel1;
                
                //Print AoA and Gratio
                if(gdist == 0 && vdist == 0){
                    gratio = 0;    
                }else if(gdist > 0 && vdist == 0){
                    gratio = NULL;
                }else{
                gratio = gdist / vdist;
                }
                fprintf(fp, "%f,%2.2f,", 0.0,gratio); 
                
                //Print temp
                fprintf(fp, "%0.2f\n", sensor_data[1]);

                
            }
            wait(1);
        } while ((rv != EOF) && button);
        
        // close file
        fclose(fp);
        
        wait_ms(50);        // button debounce
        while (!button);    // wait until button released
    }
}