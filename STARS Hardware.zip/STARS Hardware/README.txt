********************************************
**********       STARS         *************
**********      HARDWARE       *************
********************************************

This folder contains the downloaded .zip file for the STARS hardware.

If there are any issues please go to the repository located at https://developer.mbed.org/users/Albatross16/code/STARS/ 
and export the data to whichever format works best.

If you have an mbed account, you can import this repository and build it in the embedded compiler.

- STARS TEAM